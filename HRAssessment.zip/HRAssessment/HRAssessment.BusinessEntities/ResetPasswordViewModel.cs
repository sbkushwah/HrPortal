﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRAssessment.BusinessEntities
{
    public class ResetPasswordViewModel
    {
        public string Email { get; set; }
        public string ChangePasswordUrl { get; set; }
    }
}
