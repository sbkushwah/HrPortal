﻿using HRAssessment.BL.Interface;
using HRAssessment.BusinessEntities;
using Microsoft.AspNetCore.Mvc;

namespace HRAssessment.Controllers
{
    [Route("api/Consultant/")]
    [ApiController]
    public class ConsultantController : ControllerBase
    {
        public IConsultantManager ConsultantManager { get; set; }

        public ConsultantController(IConsultantManager _consultantManager)
        {
            ConsultantManager = _consultantManager;
        }

        [HttpGet]
        [Route("ConsultantList")]
        public IActionResult ConsultantList()
        {
            var response = ConsultantManager.GetConsultantList();
            var successResult = new { Result = response, ErrorCount = response != null ? 0 : 1 };
            return Ok(successResult);
        }

        [HttpGet]
        [Route("ConsultantDetails/{consultantId}")]
        public IActionResult GetConsultantDetails(int consultantId)
        {
            var response = ConsultantManager.GetConsultant(consultantId);
            var successResult = new { Result = response, ErrorCount = response != null ? 0 : 1 };
            return Ok(successResult);
        }

        [HttpPost]
        [Route("AddConsultant")]
        public IActionResult AddConsultant(ConsultantViewModel consultantModel)
        {
            var response = ConsultantManager.AddConsultant(consultantModel);
            var successResult = new { Result = response, ErrorCount = response };
            return Ok(successResult);
        }

        [HttpPut]
        [Route("UpdateConsultant")]
        public IActionResult UpdateConsultant(ConsultantViewModel consultantModel)
        {
            var response = ConsultantManager.UpdateConsultant(consultantModel);
            var successResult = new { Result = response, ErrorCount = response != null ? 0 : 1 };
            return Ok(successResult);
        }

        [HttpDelete]
        [Route("RemoveConsultant/{consultantId}")]
        public IActionResult RemoveConsultant(int consultantId)
        {
            var response = ConsultantManager.RemoveConsultant(consultantId);
            var successResult = new { Result = response, ErrorCount = response ? 0 : 1};
            return Ok(successResult);
        }
    }
}
