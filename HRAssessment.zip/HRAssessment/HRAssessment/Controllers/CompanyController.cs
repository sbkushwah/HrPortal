﻿using HRAssessment.BL.Interface;
using HRAssessment.BusinessEntities;
using Microsoft.AspNetCore.Mvc;

namespace HRAssessment.Controllers
{
    [Route("api/Company/")]
    [ApiController]
    public class CompanyController : ControllerBase
    {
        public ICompanyManager CompanyManager { get; set; }

        public CompanyController(ICompanyManager _companyManager)
        {
            CompanyManager = _companyManager;
        }

        [HttpGet]
        [Route("CompanyList")]
        public IActionResult GetCompanyList()
        {
            var response = CompanyManager.GetCompanyList();
            var successResult = new { Result = response, ErrorCount = response != null ? 0 : 1 };
            return Ok(successResult);
        }

        [HttpGet]
        [Route("CompanyDetails/{companyId}")]
        public IActionResult GetCompanyDetails(int companyId)
        {
            var response = CompanyManager.GetCompany(companyId);
            var successResult = new { Result = response, ErrorCount = response != null ? 0 : 1 };
            return Ok(successResult);
        }

        [HttpPost]
        [Route("AddCompany")]
        public IActionResult AddCompany(CompanyViewModel companyModel)
        {
            var response = CompanyManager.AddCompany(companyModel);
            var successResult = new { Result = response, ErrorCount = response };
            return Ok(successResult);
        }

        [HttpPut]
        [Route("UpdateCompany")]
        public IActionResult UpdateCompany(CompanyViewModel companyModel)
        {
            var response = CompanyManager.UpdateCompany(companyModel);
            var successResult = new { Result = response, ErrorCount = response != null ? 0 : 1 };
            return Ok(successResult);
        }

        [HttpDelete]
        [Route("RemoveCompany/{companyId}")]
        public IActionResult RemoveCompany(int companyId)
        {
            var response = CompanyManager.RemoveCompany(companyId);
            var successResult = new { Result = response, ErrorCount = response ? 0 : 1 };
            return Ok(successResult);
        }
    }
}
