﻿using HRAssessment.BL.Interface;
using HRAssessment.BusinessEntities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace HRAssessment.Controllers
{
    [Route("api/Account/")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        public IAccountManager accountManager { get; set; }

        public AccountController(IAccountManager _accountManager)
        {
            accountManager = _accountManager;
        }

        [HttpPost]
        [Route("Login")]
        public IActionResult Login(LoginViewModel loginModel)
        {
            var response = accountManager.LoginCredential(loginModel.UserEmailId, loginModel.UserPassword);
            var successResult = new { Result = response, ErrorCount = response != null ? 0 : 1 };
            return Ok(successResult);
        }

        [HttpPost]
        [Route("Registration")]
        public IActionResult Registration(RegistrationViewModel registrationModel)
        {
            var response = accountManager.RegistrationDetail(registrationModel);
            var successResult = new { Result = response, ErrorCount = response };
            return Ok(successResult);
        }
    }
}
