﻿using HRAssessment.BusinessEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRAssessment.BL.Interface
{
    public interface IConsultantManager
    {
        List<ConsultantViewModel> GetConsultantList();
        ConsultantViewModel GetConsultant(int consultantId);
        bool AddConsultant(ConsultantViewModel consultantModel);
        ConsultantViewModel UpdateConsultant(ConsultantViewModel consultantModel);
        bool RemoveConsultant(int consultantId);
    }
}
