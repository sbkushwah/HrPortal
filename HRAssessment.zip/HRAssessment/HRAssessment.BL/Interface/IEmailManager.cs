﻿using HRAssessment.BusinessEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRAssessment.BL.Interface
{
    public interface IEmailManager
    {
        Task Send(string emailAddress, string body, SendEmailParamViewModel options);
    }
}
