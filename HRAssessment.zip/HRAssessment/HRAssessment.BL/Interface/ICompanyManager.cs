﻿using HRAssessment.BusinessEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRAssessment.BL.Interface
{
    public interface ICompanyManager
    {
        List<CompanyViewModel> GetCompanyList();
        CompanyViewModel GetCompany(int companyId);
        bool AddCompany(CompanyViewModel companyModel);
        CompanyViewModel UpdateCompany(CompanyViewModel companyModel);
        bool RemoveCompany(int companyId);
    }
}
