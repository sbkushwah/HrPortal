﻿using HRAssessment.BusinessEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRAssessment.BL.Interface
{
    public interface IAccountManager
    {
        RegistrationViewModel LoginCredential(string userEmailId, string password);
        bool RegistrationDetail(RegistrationViewModel registrationModel);
        RegistrationViewModel UserDetails(string email);
    }
}
