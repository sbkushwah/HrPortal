﻿using HRAssessment.BL.Interface;
using HRAssessment.BusinessEntities;
using HRAssessment.DataAccess.Interface;
using System.Collections.Generic;

namespace HRAssessment.BL
{
    public class ConsultantManager : IConsultantManager
    {
        public IConsultantRepository consultantRepository { get; set; }

        public ConsultantManager(IConsultantRepository _consultantRepository)
        {
            consultantRepository = _consultantRepository;
        }

        public List<ConsultantViewModel> GetConsultantList()
        {
            return consultantRepository.ConsultantList();
        }

        public ConsultantViewModel GetConsultant(int consultantId)
        {
            return consultantRepository.GetConsultant(consultantId);
        }

        public bool AddConsultant(ConsultantViewModel consultantModel)
        {
            return consultantRepository.AddConsultant(consultantModel);
        }

        public ConsultantViewModel UpdateConsultant(ConsultantViewModel consultantModel)
        {
            return consultantRepository.UpdateConsultant(consultantModel);
        }

        public bool RemoveConsultant(int consultantId)
        {
            return consultantRepository.RemoveConsultant(consultantId);
        }
    }
}
