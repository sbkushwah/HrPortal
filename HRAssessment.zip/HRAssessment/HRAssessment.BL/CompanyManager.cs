﻿using HRAssessment.BL.Interface;
using HRAssessment.BusinessEntities;
using HRAssessment.DataAccess.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRAssessment.BL
{
    public class CompanyManager : ICompanyManager
    {
        public ICompanyRepository companyRepository { get; set; }

        public CompanyManager(ICompanyRepository _companyRepository)
        {
            companyRepository = _companyRepository;
        }

        public List<CompanyViewModel> GetCompanyList()
        {
            return companyRepository.CompanyList();
        }

        public CompanyViewModel GetCompany(int companyId)
        {
            return companyRepository.GetCompany(companyId);
        }

        public bool AddCompany(CompanyViewModel companyModel)
        {
            return companyRepository.AddCompany(companyModel);
        }

        public CompanyViewModel UpdateCompany(CompanyViewModel companyModel)
        {
            return companyRepository.UpdateCompany(companyModel);
        }

        public bool RemoveCompany(int companyId)
        {
            return companyRepository.RemoveCompany(companyId);
        }
    }
}
