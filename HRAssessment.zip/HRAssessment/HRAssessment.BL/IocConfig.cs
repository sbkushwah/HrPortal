﻿using HRAssessment.BL.Interface;
using Microsoft.Extensions.DependencyInjection;

namespace HRAssessment.BL
{
    public static class IocConfig
    {
        public static void ConfigureServices(ref IServiceCollection services)
        {
            services.AddTransient<IAccountManager, AccountManager>();
            services.AddTransient<IConsultantManager, ConsultantManager>();
            services.AddTransient<ICompanyManager, CompanyManager>();
            services.AddTransient<IEmailManager, EmailManager>();
        }
    }
}
