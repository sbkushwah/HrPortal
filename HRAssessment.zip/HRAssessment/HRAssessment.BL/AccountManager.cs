﻿using HRAssessment.BL.Interface;
using HRAssessment.BusinessEntities;
using HRAssessment.DataAccess.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRAssessment.BL
{
    public class AccountManager : IAccountManager
    {
        public IAccountRepository accountRepository { get; set; }

        public AccountManager(IAccountRepository _accountRepository)
        {
            accountRepository = _accountRepository;
        }

        public RegistrationViewModel LoginCredential(string userEmailId, string password)
        {
            return accountRepository.LoginCredential(userEmailId, password);
        }

        public bool RegistrationDetail(RegistrationViewModel registrationModel)
        {
            return accountRepository.RegistrationDetail(registrationModel);
        }

        public RegistrationViewModel UserDetails(string email)
        {
            return accountRepository.UserDetails(email);
        }
    }
}
