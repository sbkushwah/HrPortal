﻿using HRAssessment.BL.Interface;
using HRAssessment.BusinessEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace HRAssessment.BL
{
    public class EmailManager: IEmailManager
    {
        public EmailManager()
        {

        }
        public async Task Send(string emailAddress, string body, SendEmailParamViewModel options)
        {
            var client = new SmtpClient();
            client.Host = options.Host;
            client.Credentials = new NetworkCredential(options.APIKey, options.APIKeySecret);
            client.Port = options.Port;

            var message = new MailMessage(options.SenderEmail, emailAddress);
            message.Body = body;
            message.IsBodyHtml = true;

            await client.SendMailAsync(message);
        }
    }
}
