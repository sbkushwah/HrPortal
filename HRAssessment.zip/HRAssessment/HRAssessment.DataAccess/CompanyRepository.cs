﻿using HRAssessment.BusinessEntities;
using HRAssessment.DataAccess.Interface;
using HRAssessment.DataEntities;
using HRAssessment.DataEntities.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRAssessment.DataAccess
{
    public class CompanyRepository : ICompanyRepository
    {
        private readonly RepositoryContext _dbContext;
        public CompanyRepository(RepositoryContext dbContext)
        {
            _dbContext = dbContext;
        }

        public List<CompanyViewModel> CompanyList()
        {
            var data = _dbContext.Company.ToList();
            var serResult = JsonConvert.SerializeObject(data);
            return (List<CompanyViewModel>)JsonConvert.DeserializeObject<IList<CompanyViewModel>>(serResult);
        }

        public CompanyViewModel GetCompany(int companyId)
        {
            var result = _dbContext.Company.FirstOrDefault(x => x.Id == companyId);
            var companyData = new CompanyViewModel
            {
                Id = result.Id,
                CompanyName = result.CompanyName,
                IsActive = result.IsActive,
                CreatedDate = result.CreatedDate
            };
            return companyData;
        }

        public bool AddCompany(CompanyViewModel companyModel)
        {
            var companyData = new Company
            {
                CompanyName = companyModel.CompanyName,
                IsActive = companyModel.IsActive,
                CreatedDate = DateTime.Now
            };

            var companyResult = _dbContext.Company.Add(companyData);
            _dbContext.SaveChanges();
            return (companyResult.Entity != null) ? true : false;
        }

        public CompanyViewModel UpdateCompany(CompanyViewModel companyModel)
        {
            var companyData = new Company
            {
                Id = companyModel.Id,
                CompanyName = companyModel.CompanyName,
                IsActive = companyModel.IsActive,
                UpdatedDate = DateTime.Now
            };

            var companyResult = _dbContext.Company.Update(companyData);
            _dbContext.SaveChanges();
            var serResult = JsonConvert.SerializeObject(companyResult.Entity);
            return JsonConvert.DeserializeObject<CompanyViewModel>(serResult);
        }

        public bool RemoveCompany(int companyId)
        {
            bool isRemove = false;
            var data = _dbContext.Company.FirstOrDefault(x => x.Id == companyId);
            if (data != null)
            {
                _dbContext.Remove(data);
                _dbContext.SaveChanges();
                isRemove = true;
            }
            return isRemove;
        }
    }
}
