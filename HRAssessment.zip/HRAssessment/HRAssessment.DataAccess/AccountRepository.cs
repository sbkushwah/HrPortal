﻿using HRAssessment.BusinessEntities;
using HRAssessment.DataAccess.Interface;
using HRAssessment.DataEntities;
using HRAssessment.DataEntities.Model;
using Newtonsoft.Json;
using System;
using System.Linq;

namespace HRAssessment.DataAccess
{
    public class AccountRepository : IAccountRepository
    {
        private readonly RepositoryContext _dbContext;
        public AccountRepository(RepositoryContext dbContext)
        {
            _dbContext = dbContext;
        }
        public RegistrationViewModel LoginCredential(string userEmailId, string password)
        {
            var data = _dbContext.Login.FirstOrDefault(x=> x.UserEmailId.Equals(userEmailId) && x.UserPassword.Equals(password));
            string serResult = JsonConvert.SerializeObject(data);
            var desResult = JsonConvert.DeserializeObject<LoginViewModel>(serResult);
            var result = _dbContext.Registration.FirstOrDefault(x => x.Email.Equals(desResult.UserEmailId));
            var companyCount = _dbContext.Company.Count(x => x.IsActive);
            var consultantCount = _dbContext.Consultant.Count(x => x.Status);
            var userData = new RegistrationViewModel
            {
                Id = result.Id,
                FirstName = result.FirstName,
                LastName = result.LastName,
                Email = result.Email,
                UserName = desResult.UserEmailId,
                Password = desResult.UserPassword,
                CompanyCount = companyCount,
                ConsultantCount = consultantCount
            };
            return userData;
        }

        public bool RegistrationDetail(RegistrationViewModel registrationModel)
        {
            var registrationData = new Registration
            {
                FirstName = registrationModel.FirstName,
                LastName = registrationModel.LastName,
                DateOfBirth = registrationModel.DateOfBirth,
                Email = registrationModel.Email,
                Password = registrationModel.Password,
                ConfirmPassword = registrationModel.ConfirmPassword,
                CreatedDate = DateTime.Now
            };
            var loginData = new Login
            {
                UserEmailId = registrationModel.Email,
                UserPassword = registrationModel.Password
            };
            var registerResult = _dbContext.Registration.Add(registrationData);
            _dbContext.Login.Add(loginData);
            _dbContext.SaveChanges();
            return (registerResult.Entity != null) ? true : false;
        }

        public RegistrationViewModel UserDetails(string email)
        {
            var result = _dbContext.Registration.FirstOrDefault(x => x.Email.ToLower().Equals(email.ToLower()));
            var userData = new RegistrationViewModel
            {
                Id = result.Id,
                FirstName = result.FirstName,
                LastName = result.LastName,
                Email = result.Email,
            };
            return userData;
        }
    }
}
