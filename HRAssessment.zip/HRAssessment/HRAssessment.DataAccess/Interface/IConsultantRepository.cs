﻿using HRAssessment.BusinessEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRAssessment.DataAccess.Interface
{
    public interface IConsultantRepository
    {
        List<ConsultantViewModel> ConsultantList();
        ConsultantViewModel GetConsultant(int consultantId);
        bool AddConsultant(ConsultantViewModel consultantModel);
        ConsultantViewModel UpdateConsultant(ConsultantViewModel consultantModel);
        bool RemoveConsultant(int consultantId);
    }
}
