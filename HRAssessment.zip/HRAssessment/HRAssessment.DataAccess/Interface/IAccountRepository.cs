﻿using HRAssessment.BusinessEntities;
using HRAssessment.DataEntities.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRAssessment.DataAccess.Interface
{
    public interface IAccountRepository
    {
        RegistrationViewModel LoginCredential(string userEmailId, string password);
        bool RegistrationDetail(RegistrationViewModel registrationModel);
        RegistrationViewModel UserDetails(string email);
    }
}
