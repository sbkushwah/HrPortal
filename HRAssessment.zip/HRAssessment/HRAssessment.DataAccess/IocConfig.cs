﻿using HRAssessment.DataAccess.Interface;
using HRAssessment.DataEntities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace HRAssessment.DataAccess
{
    public static class IocConfig
    {
        public static void ConfigureServices(ref IServiceCollection services)
        {
            var sp = services.BuildServiceProvider();
            var settingService = sp.GetService<IConfiguration>();
            string DbConnString = settingService.GetValue<string>("ConnectionString:AssessmentDb");
            services.AddDbContext<RepositoryContext>(options => options.UseSqlServer(DbConnString), ServiceLifetime.Transient);
            services.AddTransient<IAccountRepository, AccountRepository>();
            services.AddTransient<IConsultantRepository, ConsultantRepository>();
            services.AddTransient<ICompanyRepository, CompanyRepository>();
        }
    }
}
