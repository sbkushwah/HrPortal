﻿using HRAssessment.BusinessEntities;
using HRAssessment.DataAccess.Interface;
using HRAssessment.DataEntities;
using HRAssessment.DataEntities.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRAssessment.DataAccess
{
    public class ConsultantRepository : IConsultantRepository
    {
        private readonly RepositoryContext _dbContext;
        public ConsultantRepository(RepositoryContext dbContext)
        {
            _dbContext = dbContext;
        }

        public List<ConsultantViewModel> ConsultantList()
        {
            var data = _dbContext.Consultant.ToList();
            var serResult = JsonConvert.SerializeObject(data);
            return (List<ConsultantViewModel>)JsonConvert.DeserializeObject<IList<ConsultantViewModel>>(serResult);
        }

        public ConsultantViewModel GetConsultant(int consultantId)
        {
            var result = _dbContext.Consultant.FirstOrDefault(x => x.Id == consultantId);
            var consultantData = new ConsultantViewModel
            {
                Id = result.Id,
                FirstName = result.FirstName,
                LastName = result.LastName,
                EmailId = result.EmailId,
                IsAdmin = result.IsAdmin,
                Status = result.Status,
                Company = result.Company,
                CreatedDate = result.CreatedDate
            };
            return consultantData;
        }

        public bool AddConsultant(ConsultantViewModel consultantModel)
        {
            var consultantData = new Consultant
            {
                FirstName = consultantModel.FirstName,
                LastName = consultantModel.LastName,
                EmailId = consultantModel.EmailId,
                IsAdmin = consultantModel.IsAdmin,
                Status = consultantModel.Status,
                Company = consultantModel.Company,
                CreatedDate = DateTime.Now
            };

            var consultantResult = _dbContext.Consultant.Add(consultantData);
            _dbContext.SaveChanges();
            return (consultantResult.Entity != null) ? true : false;
        }

        public ConsultantViewModel UpdateConsultant(ConsultantViewModel consultantModel)
        {
            var consultantData = new Consultant
            {
                Id = consultantModel.Id,
                FirstName = consultantModel.FirstName,
                LastName = consultantModel.LastName,
                EmailId = consultantModel.EmailId,
                IsAdmin = consultantModel.IsAdmin,
                Status = consultantModel.Status,
                Company = consultantModel.Company,
                CreatedDate = DateTime.Now
            };

            var consultantResult = _dbContext.Consultant.Update(consultantData);
            _dbContext.SaveChanges();
            var serResult = JsonConvert.SerializeObject(consultantResult.Entity);
            return JsonConvert.DeserializeObject<ConsultantViewModel>(serResult);
        }

        public bool RemoveConsultant(int consultantId)
        {
            bool isRemove = false;
            var data = _dbContext.Consultant.FirstOrDefault(x => x.Id == consultantId);
            if (data != null)
            {
                _dbContext.Remove(data);
                _dbContext.SaveChanges();
                isRemove = true;
            }
            return isRemove;
        }
    }
}
