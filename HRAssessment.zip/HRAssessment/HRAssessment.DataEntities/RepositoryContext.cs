﻿using HRAssessment.DataEntities.Model;
using Microsoft.EntityFrameworkCore;

namespace HRAssessment.DataEntities
{
    public class RepositoryContext : DbContext
    {
        public RepositoryContext(DbContextOptions options)
            : base(options)
        {
        }

        public DbSet<Registration> Registration { get; set; }
        public DbSet<Login> Login { get; set; }
        public DbSet<Consultant> Consultant { get; set; }
        public DbSet<Company> Company { get; set; }
    }
}
