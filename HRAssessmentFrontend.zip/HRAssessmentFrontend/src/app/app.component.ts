﻿import { Component } from '@angular/core';

import { AccountService } from './_services';
import { User } from './_models';
import * as $ from 'jquery';
@Component({ selector: 'app', templateUrl: 'app.component.html', styleUrls: ['./app.component.css']  })
export class AppComponent {
    user: User;

    constructor(private accountService: AccountService) {
        this.accountService.user.subscribe(x => this.user = x);
    }

    ngOnInit() {
        //Toggle Click Function
        $("#menu-toggle").click(function (e) {
            debugger;
            e.preventDefault();
            $("#wrapper").toggleClass("toggled");
        });
    }

    logout() {
        this.accountService.logout();
    }
}