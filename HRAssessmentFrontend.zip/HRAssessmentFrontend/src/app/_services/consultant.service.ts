import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, Subject, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ConsultantService {
  private apiURL = "http://localhost:49530/api";
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(private httpClient: HttpClient) { }
  getConsultantList(): Observable<any[]> {
    return this.httpClient.get<any[]>(this.apiURL + '/Consultant/ConsultantList')
      .pipe(
        catchError(this.errorHandler)
      );
  }

  getConsultantDetails(id): Observable<any> {
    return this.httpClient.get<any>(this.apiURL+`/Consultant/ConsultantDetails/${id}`)
      .pipe(
        catchError(this.errorHandler)
      );
  }

  AddConsultant(consultant): Observable<any> {
    return this.httpClient.post<any>(this.apiURL + '/Consultant/AddConsultant/', JSON.stringify(consultant), this.httpOptions)
      .pipe(
        catchError(this.errorHandler)
      );
  }

  UpdateConsultant(consultant): Observable<any> {
    return this.httpClient.put<any>(this.apiURL + '/Consultant/UpdateConsultant', JSON.stringify(consultant), this.httpOptions)
      .pipe(
        catchError(this.errorHandler)
      );
  }

  deleteConsultant(id) {
    return this.httpClient.delete<any>(this.apiURL + '/Consultant/RemoveConsultant/' + id, this.httpOptions)
      .pipe(
        catchError(this.errorHandler)
      );
  }

  errorHandler(error) {
    let errorMessage = '';

    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}
