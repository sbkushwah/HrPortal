import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, Subject, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CompanyService {

  private apiURL = "http://localhost:49530/api";
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(private httpClient: HttpClient) { }
  getCompanyList(): Observable<any[]> {
    return this.httpClient.get<any[]>(this.apiURL + '/Company/CompanyList')
      .pipe(
        catchError(this.errorHandler)
      );
  }

  getCompanyDetails(id): Observable<any> {
    return this.httpClient.get<any>(this.apiURL+`/Company/CompanyDetails/${id}`)
      .pipe(
        catchError(this.errorHandler)
      );
  }

  AddCompany(company): Observable<any> {
    return this.httpClient.post<any>(this.apiURL + '/Company/AddCompany/', JSON.stringify(company), this.httpOptions)
      .pipe(
        catchError(this.errorHandler)
      );
  }

  UpdateCompany(company): Observable<any> {
    return this.httpClient.put<any>(this.apiURL + '/Company/UpdateCompany', JSON.stringify(company), this.httpOptions)
      .pipe(
        catchError(this.errorHandler)
      );
  }

  deleteCompany(id) {
    return this.httpClient.delete<any>(this.apiURL + '/Company/RemoveCompany/' + id, this.httpOptions)
      .pipe(
        catchError(this.errorHandler)
      );
  }

  errorHandler(error) {
    let errorMessage = '';

    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}
