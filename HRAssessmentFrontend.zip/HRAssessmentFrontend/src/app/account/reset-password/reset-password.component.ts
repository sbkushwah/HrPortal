import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AccountService, AlertService } from '@app/_services';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.less']
})
export class ResetPasswordComponent implements OnInit {

  constructor(private accountService: AccountService,
    private alertService: AlertService) { }

  ngOnInit(): void {
  }

  onSubmit(f: NgForm) {
    this.alertService.info('Working on sending email');
    const resetPasswordObserver = {
      next: x => {
        this.alertService.success('Check email to change password');
        console.log('Check email to change password');
      },
      error: err => {
        console.log(err);
        this.alertService.error('Unable to send email');
      }
    };
    this.accountService.register(f.value).subscribe(resetPasswordObserver);
  }
}
