import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { UsersRoutingModule } from './users-routing.module';
import { LayoutComponent } from './layout.component';
import { ListComponent } from './list.component';
import { AddEditComponent } from './add-edit.component';
import { AppFilterPipe } from '@app/_pipe/app-filter.pipe';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { NgxPaginationModule } from 'ngx-pagination';
import { SortableDirective } from '@app/_directive/sortable.directive';
import { ProfileComponent } from './profile.component';
import { CompanyComponent } from './company/company.component';
import { CompanyAddEditComponent } from './company/company-add-edit/company-add-edit.component'

@NgModule({
    imports: [
        FormsModule,
        Ng2SearchPipeModule,
        CommonModule,
        ReactiveFormsModule,
        UsersRoutingModule,
        NgxPaginationModule,
        //CompanyModule
    ],
    declarations: [
        LayoutComponent,
        ListComponent,
        AddEditComponent,
        AppFilterPipe,
        SortableDirective,
        ProfileComponent,
        CompanyComponent,
        CompanyAddEditComponent
    ]
})
export class UsersModule { }