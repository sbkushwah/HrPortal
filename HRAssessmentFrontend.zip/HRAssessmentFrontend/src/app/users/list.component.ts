﻿import { Component, Directive, OnInit, QueryList, ViewChildren } from '@angular/core';
import { first } from 'rxjs/operators';
import { AccountService, ConsultantService } from '@app/_services';
import { User } from '@app/_models';
import { SortableDirective } from '@app/_directive/sortable.directive';
import { Observable } from 'rxjs';

@Component({ templateUrl: 'list.component.html' })
export class ListComponent implements OnInit {
    consultants: any;
    searchText = '';
    page = 1;
    count = 0;
    tableSize = 4;
    tableSizes = [5,10,15,20];
    constructor(private consultantService: ConsultantService) { }

    ngOnInit() {
        this.GetConsultantList();
    }

    GetConsultantList() {
      this.consultantService.getConsultantList().subscribe((data: any) => {
        this.consultants = data.result;
      });
    }
    onTableDataChange(event){
      this.page = event;
      this.GetConsultantList();
    }  
  
    onTableSizeChange(event): void {
      this.tableSize = event.target.value;
      this.page = 1;
      this.GetConsultantList();
    }  

    deleteUser(id: string) {
        const user = this.consultants.find(x => x.id === id);
        user.isDeleting = true;
        this.consultantService.deleteConsultant(id)
            .pipe(first())
            .subscribe(() => this.consultants = this.consultants.filter(x => x.id !== id));
    }

    // onSortClick(event) {
    //     let target = event.currentTarget,
    //       classList = target.classList;
    
    //     if (classList.contains('fa-chevron-up')) {
    //       classList.remove('fa-chevron-up');
    //       classList.add('fa-chevron-down');
    //       this.sortDir=-1;
    //     } else {
    //       classList.add('fa-chevron-up');
    //       classList.remove('fa-chevron-down');
    //       this.sortDir=1;
    //     }
    //     //this.sortArr('fname');
    //   }
}