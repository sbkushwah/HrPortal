import { Component, OnInit } from '@angular/core';
import { CompanyService } from '@app/_services';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html'
})
export class CompanyComponent implements OnInit {
  companys: any;
  searchText = '';
  page = 1;
  count = 0;
  tableSize = 4;
  tableSizes = [5, 10, 15, 20];
  constructor(private companyService: CompanyService) { 
  }

  ngOnInit() {
    this.GetCompanyList();
  }

  GetCompanyList() {
    this.companyService.getCompanyList().subscribe((data: any) => {
      this.companys = data.result;
    });
  }
  onTableDataChange(event) {
    this.page = event;
    this.GetCompanyList();
  }

  onTableSizeChange(event): void {
    this.tableSize = event.target.value;
    this.page = 1;
    this.GetCompanyList();
  }

  deleteCompany(id: string) {
    const companyData = this.companys.find(x => x.id === id);
    companyData.isDeleting = true;
    this.companyService.deleteCompany(id)
      .pipe(first())
      .subscribe(() => this.companys = this.companys.filter(x => x.id !== id));
  }
}
