import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertService, CompanyService, ConsultantService } from '@app/_services';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-company-add-edit',
  templateUrl: './company-add-edit.component.html',
  styleUrls: ['./company-add-edit.component.less']
})
export class CompanyAddEditComponent implements OnInit {
  form: FormGroup;
  id: string;
  isAddMode: boolean;
  loading = false;
  submitted = false;
  companyData: any;

  constructor(
      private formBuilder: FormBuilder,
      private route: ActivatedRoute,
      private router: Router,
      private companyService: CompanyService,
      private alertService: AlertService
  ) { }

  ngOnInit() {
      this.id = this.route.snapshot.params['id'];
      this.isAddMode = !this.id;

      // password not required in edit mode
      //const passwordValidators = [Validators.minLength(6)];
      // if (this.isAddMode) {
      //     passwordValidators.push(Validators.required);
      // }

      this.form = this.formBuilder.group({
          companyName: ['', Validators.required],
          isActive: ['']
      });

      if (!this.isAddMode) {
          this.companyService.getCompanyDetails(this.id)
              .subscribe((data: any) => {
                  this.companyData = data.result;
                  this.form = this.formBuilder.group({
                      id: [this.id],
                      companyName: [this.companyData.companyName],
                      isActive: [this.companyData.isActive]
                  });
              });
      }
  }

  // convenience getter for easy access to form fields
  get f() { return this.form.controls; }

  onSubmit() {
      this.submitted = true;

      // reset alerts on submit
      this.alertService.clear();

      // stop here if form is invalid
      if (this.form.invalid) {
          return;
      }

      this.loading = true;
      if (this.isAddMode) {
          this.createCompany();
      } else {
          this.updateCompany();
      }
  }

  private createCompany() {
      this.companyService.AddCompany(this.form.value)
          .pipe(first())
          .subscribe({
              next: () => {
                  this.alertService.success('Company added successfully', { keepAfterRouteChange: true });
                  this.router.navigate(['../'], { relativeTo: this.route });
              },
              error: error => {
                  this.alertService.error(error);
                  this.loading = false;
              }
          });
  }

  private updateCompany() {
      this.companyService.UpdateCompany(this.form.value)
          .pipe(first())
          .subscribe({
              next: () => {
                  this.alertService.success('Update successful', { keepAfterRouteChange: true });
                  this.router.navigate(['../../'], { relativeTo: this.route });
              },
              error: error => {
                  this.alertService.error(error);
                  this.loading = false;
              }
          });
  }
}
