import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService, ConsultantService } from '@app/_services';

@Component({
  selector: 'profile',
  templateUrl: './profile.component.html'
})
export class ProfileComponent implements OnInit {

  form: FormGroup;
  id: string;
  isAddMode: boolean;
  loading = false;
  submitted = false;
  consultant: any;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private consultantService: ConsultantService,
    private accountService: AccountService
  ) { }

  ngOnInit() {
    debugger;
    this.id = this.accountService.userValue.id;
    this.form = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      emailId: [''],
      status: [''],
      isAdmin: [''],
      company: ['']
    });

    if (!this.isAddMode) {
      this.consultantService.getConsultantDetails(this.id)
        .subscribe((data: any) => {
          this.consultant = data.result;
          this.form = this.formBuilder.group({
            id: [this.id],
            firstName: [this.consultant.firstName],
            lastName: [this.consultant.lastName],
            emailId: [this.consultant.emailId],
            status: [this.consultant.status],
            isAdmin: [this.consultant.isAdmin],
            company: [this.consultant.company]
          });
          console.log(this.consultant);
        });
    }
  }

  // convenience getter for easy access to form fields
  get f() { return this.form.controls; }

}
