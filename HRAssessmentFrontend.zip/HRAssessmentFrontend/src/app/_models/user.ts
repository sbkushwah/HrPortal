﻿export class User {
    id: string;
    firstName: string;
    lastName: string;
    dateOfBirth: Date;
    email: string;
    password: string;
    confirmPassword: string;
    consultantCount:number;
    companyCount: number;
    createdDate: Date;    
    token: string;
}